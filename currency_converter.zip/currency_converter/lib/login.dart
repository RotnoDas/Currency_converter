import 'package:currency_converter/screens/home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LoginUserInApp {
  void loginUser(String email, String password,  BuildContext context) async {
    if(email.isEmpty || password.isEmpty ){
      showErrorDialog(context, 'Please Enter every info');
    }
    else{
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
      Navigator.push(context, MaterialPageRoute(builder: (context) =>const Home(),));
      
    } on FirebaseAuthException catch (e) {
      showErrorDialog(context, e.code);
    } 
    }
    
  }

  Future<void> showErrorDialog(
    BuildContext context,
    String message,
  ) {
    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text(message),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Got it'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
