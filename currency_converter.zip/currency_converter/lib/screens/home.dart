import 'package:currency_converter/components/anyToAny.dart';
//import 'package:currency_converter/components/usdToAny.dart';
import 'package:currency_converter/models/ratesmodel.dart';
import 'package:flutter/material.dart';

import '../functions/fetchrates.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late Future<RatesModel> result;  // fetched rates model from the database
  late Future<Map> allCurrencies;  // fetched list of all currencies

  final formkey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    result = fetchrates();
    allCurrencies = fetchcurrencies();
  }

  Widget build(BuildContext context) {
    var h = MediaQuery.of(context).size.height;  // Responsive of particular device.
    var w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(0),
              bottomLeft: Radius.circular(0)),
        ),
        toolbarHeight: 65,
        elevation: 50,
        shadowColor: Colors.greenAccent,
        backgroundColor: Colors.greenAccent,
        foregroundColor: Colors.black,
        title: const Text('Currency Converter', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600, fontStyle: FontStyle.italic),),
        centerTitle: false,
      ),

      body: Container(
          height: h,
          width: w,
          padding: EdgeInsets.only(top: 65, left: 15, right: 15),
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/demo.png'),
              fit: BoxFit.cover,
            ),
          ),
          child: SingleChildScrollView(   // Because of keyboard.
            child: Form(
              key: formkey,

              child: FutureBuilder<RatesModel>(
                future: result,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }
                  
                  return Center(
                      child: FutureBuilder<Map>(
                    future: allCurrencies,
                    builder: (context, currSnapshot) {
                      if (currSnapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const Center(
                          child: CircularProgressIndicator(),    // Loading state. Fetching data.
                        );
                      }
                      return Column(
                        children: [
                          /*UsdToAny(
                              rates: snapshot.data!.rates,
                              currencies: currSnapshot.data!),*/ //-----------------------------------------------------------
                          SizedBox(
                            height: 8,
                          ),
                          AnyToAny(
                              rates: snapshot.data!.rates,
                              currencies: currSnapshot.data!)
                        ],
                      );
                    },
                  ));
                },
              ),
            ),
          )),
    );
  }
}