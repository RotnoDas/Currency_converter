
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:currency_converter/screens/home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class SignupUserInApp {

  void signupUser(String email, String password, String confirmPassword,
      String userName, BuildContext context) async {
    UserCredential? userCredential;
    if(email.isEmpty || password.isEmpty || confirmPassword.isEmpty || userName.isEmpty){
      showErrorDialog(context, 'Please Enter every info');
    }
    else if(password != confirmPassword){
      showErrorDialog(context, 'Make sure password and confirm password is same');
    }  // Sign up process using error handling process.

    else{
    try {
      userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email, password: password);

      saveUserInfo(userCredential, userName);
      Navigator.push(context, MaterialPageRoute(builder: (context) =>const Home(),));
      
    } on FirebaseAuthException catch (e) {
      showErrorDialog(context, e.code);
    } 
    }
    
  }

  // Error dialog to display error messages.
  Future<void> showErrorDialog(
    BuildContext context,
    String message,
  ) {
    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text(message),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Got it'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


  void saveUserInfo(
    UserCredential userCredential,
    String userName
  ){
    FirebaseFirestore.instance.collection('users').doc(userCredential.user!.email).set({
      'userName' : userName,
      'email' : userCredential.user!.email
    });
  }
}
