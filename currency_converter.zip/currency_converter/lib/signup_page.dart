import 'package:currency_converter/design_for_login_and_signup.dart';
import 'package:currency_converter/login_page.dart';
import 'package:currency_converter/signup.dart';
import 'package:flutter/material.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _emailController = TextEditingController();  //
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _userNameController = TextEditingController();
  Fields fields = Fields();
  SignupUserInApp singup = SignupUserInApp();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amberAccent,
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                child: Icon(Icons.person,size: 200,),
              ),
              SizedBox(
                height:MediaQuery.of(context).size.height * .05,
                child: Text('Sign Up Here',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 25),)),

            
                SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),

              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                child: TextField(
                  controller: _userNameController,
                  decoration: fields.textFieldDecoration('User name', Icons.person),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                child: TextField(
                  controller: _emailController,
                  decoration: fields.textFieldDecoration('Email', Icons.email),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                child: TextField(
                  controller: _passwordController,
                  decoration: fields.textFieldDecoration('Password', Icons.key),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                child: TextField(
                  controller: _confirmPasswordController,
                  decoration: fields.textFieldDecoration('Confirm password', Icons.key),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              ElevatedButton(onPressed: (){
                singup.signupUser(_emailController.text, _passwordController.text, _confirmPasswordController.text, _userNameController.text, context);
              }, child: Text('Sign Up', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 15))),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              TextButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginPage(),));
              }, child: Text('Already have an account? Login Now', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
            ],
          ),
        ),
      ),
    );
  }
}