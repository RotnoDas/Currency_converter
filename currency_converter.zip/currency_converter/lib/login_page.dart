import 'package:currency_converter/design_for_login_and_signup.dart';
import 'package:currency_converter/login.dart';
import 'package:currency_converter/signup_page.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  LoginUserInApp login = LoginUserInApp();
  Fields fields = Fields();
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.amberAccent,
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                child: Icon(Icons.person,size: 200,),
              ),
              SizedBox(
                height:MediaQuery.of(context).size.height * .05,
                child: Text('Login Here',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 25),)),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                child: TextField(
                  controller: _emailController,
                  decoration: fields.textFieldDecoration('Email', Icons.email),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                child: TextField(
                  controller: _passwordController,
                  decoration: fields.textFieldDecoration('Password', Icons.key),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              ElevatedButton(onPressed: (){
                login.loginUser(_emailController.text, _passwordController.text, context);
              }, child: Text('Login', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 15))
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height*.01,
              ),
              TextButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => const SignupPage(),));
              }, child: const Text('Do not have an account? Sign up now', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),))
            ],
          ),
        ),
      ),
    );
  }
}