import 'package:flutter/material.dart';

class Fields{
  InputDecoration textFieldDecoration(
    String hintText,
    IconData prefixIcon,
  ){
    return InputDecoration(
      hintText: hintText,
      prefixIcon: Icon(prefixIcon),
      fillColor: Colors.grey,
      filled: true,
      border: OutlineInputBorder(
        borderSide: BorderSide.none,
        borderRadius: BorderRadius.circular(20),
      )
    );
  }
}