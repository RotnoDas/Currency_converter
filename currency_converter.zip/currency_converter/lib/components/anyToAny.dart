//import 'dart:ffi';
import 'dart:ui';

import 'package:currency_converter/functions/fetchrates.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';

class AnyToAny extends StatefulWidget {
  final rates;
  final Map currencies;
  const AnyToAny({Key? key, @required this.rates, required this.currencies})
      : super(key: key);

  @override
  _AnyToAnyState createState() => _AnyToAnyState();
} // widget that allows for currency conversion.

class _AnyToAnyState extends State<AnyToAny> {
  TextEditingController amountController = TextEditingController();  // Amount to be converted.
  String dropdownValue1 = 'USD';
  String dropdownValue2 = 'BDT';
  String answer = 'Converted currency will be shown here';

  @override
  Widget build(BuildContext context) {
    var w = MediaQuery.of(context).size.width;
    return Card(
      color: Colors.black45,
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              alignment: Alignment.center,
              child: const Text(
                'Convert any currency',
                textAlign: TextAlign.right,
                style: TextStyle(
                    fontSize: 25,
                    fontStyle: FontStyle.italic,
                    fontWeight: FontWeight.bold,
                    color: Colors.yellow),
              ),
            ),
            const SizedBox(
              height: 30,
            ),

            TextFormField(
              key: const ValueKey('amount',),
              controller: amountController,
              cursorColor: Colors.grey,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                icon: Icon(Icons.animation_rounded),
                hintText: 'Enter amount',
                helperText: 'Given Amount',
                helperStyle: TextStyle(color: Colors.greenAccent),
                //counterText: '0 characters',
                //counterStyle: TextStyle(color: Colors.greenAccent),
                hintStyle: TextStyle(color: Colors.grey),
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.limeAccent),
                  borderRadius: BorderRadius.all(Radius.circular(15)),
                ),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(
              height: 20,
            ),

            Row(
              children: [
                Expanded(
                  child: DropdownButton<String>(
                    dropdownColor: Colors.black,
                    value: dropdownValue1,
                    style: const TextStyle(color: Colors.white, fontStyle: FontStyle.italic),
                    icon: const Icon(
                      Icons.arrow_drop_down_rounded,
                      color: Colors.white,
                    ),
                    iconSize: 24,
                    elevation: 200,
                    isExpanded: true,
                    underline: Container(
                      height: 2,
                      color: Colors.grey.shade400,
                    ),
                    onChanged: (String? newValue) {
                      setState(() {
                        dropdownValue1 = newValue!;
                      });
                    },
                    items: widget.currencies.keys
                        .toSet()
                        .toList()
                        .map<DropdownMenuItem<String>>((value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value, style: TextStyle(color: Colors.white)),
                      );
                    }).toList(),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  child: const Text('TO',
                  style: TextStyle(color: Colors.white))),
                Expanded(
                  child: DropdownButton<String>(
                    dropdownColor: Colors.black,
                    value: dropdownValue2,
                    style: const TextStyle(color: Colors.white, fontStyle: FontStyle.italic),
                    icon: const Icon(
                      Icons.arrow_drop_down_rounded,
                      color: Colors.white,
                    ),
                    iconSize: 24,
                    elevation: 200,
                    isExpanded: true,
                    underline: Container(
                      height: 2,
                      color: Colors.grey.shade400,
                    ),
                    onChanged: (String? newValue) {
                      setState(() {
                        dropdownValue2 = newValue!;
                      });
                    },
                    items: widget.currencies.keys
                    .toSet()
                    .toList()
                    .map<DropdownMenuItem<String>>((value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value, 
                        style: TextStyle(color: Colors.white)),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
            const SizedBox(
                  height: 35,
                ),
                Container(
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        answer = amountController.text +
                            ' ' +
                            dropdownValue1 +
                            '    =    ' +
                            convertany(widget.rates, amountController.text,
                            dropdownValue1, dropdownValue2) +
                            ' ' +
                            dropdownValue2;
                      });
                    },
                    child: const Text('Convert', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 15)),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.redAccent),
                      overlayColor: MaterialStatePropertyAll(Colors.greenAccent),
                      //shadowColor: MaterialStatePropertyAll(Colors.greenAccent),
                    ),
                  ),
                ),
            const SizedBox(
              width: 15,
            ),
            const SizedBox(height: 25),
            Container(
              child: Text(answer, style: const TextStyle(color: Colors.lightGreenAccent, fontWeight: FontWeight.bold, fontSize: 18, fontStyle: FontStyle.italic)))
              // Displaying result.
          ],
        ),
      ),
    );
  }
}